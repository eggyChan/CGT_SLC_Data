This is the dataset of the CrGeTe3 spin-lattice coupling paper. 
--------------------------------------------------------------------
For matlab .m files, simply run the code. Remember to import the .mat dataset.
--------------------------------------------------------------------
For matlab .fig files, open the figure, then run:
fig = gcf;
axObjs = fig.Children;
dataObjs = axObjs.Children;
x = dataObjs(1).XData;
y = dataObjs(1).YData;
z = dataObjs(1).ZData; (if applicable)
or run other appropriate codes that extracts data from figure.
--------------------------------------------------------------------
For .spe files, simply open with text editor, 
Or download and install DAVE from https://www.ncnr.nist.gov/dave/, 
Start the program, click analysis/MSlice - TOF/TAS Analysis, 
Then in the pop-up window, click file/Read and plot ASCII data file, 
The .spe files can be opened.
--------------------------------------------------------------------