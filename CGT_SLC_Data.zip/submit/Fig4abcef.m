%% CGT rhombohedral lattice
%load('IntegrFit_err_v2.mat')
CGT = spinw;
CGT.genlattice('lat_const',[6.82 6.82 20.37],'angled',[90 90 120],'spgr','R -3')
CGT.addatom('r', [1/3 2/3 0.33299], 'S', 3/2, 'label','Cr3+','formfact','MCr3+','color','b')
disp('Magnetic atom positions:')
CGT.table('matom')
plot(CGT,'range',[2 2 1])

% Create BB bonds
CGT.gencoupling('maxDistance',8.0)
disp('Bonds (length in Angstrom):')
CGT.table('bond',[])

Js = [-2.57 -0.15 -0.19 -0.70 0  0.25 -0.03]

CGT.addmatrix('label','J1','value',Js(1),'color','orange'); % FM < 0
CGT.addcoupling('mat','J1','bond',1);
CGT.addmatrix('label','J2','value',Js(2),'color','green');
CGT.addcoupling('mat','J2','bond',3);
CGT.addmatrix('label','J3','value',Js(3),'color','blue');
CGT.addcoupling('mat','J3','bond',6);
CGT.addmatrix('label','Jc1','value',Js(4),'color','red');
CGT.addcoupling('mat','Jc1','bond',2);
CGT.addmatrix('label','Jc2','value',Js(5),'color','purple');
CGT.addcoupling('mat','Jc2','bond',4);
CGT.addmatrix('label','Jc3','value',Js(5),'color','green');
CGT.addcoupling('mat','Jc3','bond',5);
CGT.addmatrix('label','DM2','value',1,'color','black')
CGT.addcoupling('mat','DM2','bond',3);
CGT.setmatrix('mat','DM2','pref',{[0 0 Js(6)]});
CGT.addmatrix('label','D','value',diag([0 0 Js(7)]),'color','yellow');
CGT.addaniso('D'); % The value of D is only an estimate.
% set magnetic field


% Plot a nice rectangular cutout of the lattice
%plot(CGT,'range',[1 1 1],'unit','xyz','cellMode','single')

% FM magnetic structure
CGT.genmagstr('mode','helical','k',[0 0 0],'n',[0 1 0],'S',[0; 0; 1])
% AFM magnetic structure
%CGT.genmagstr('mode','helical','k',[0 0 3/2],'n',[0 1 0],'S',[0; 0; 1])
disp('Magnetic structure:')
CGT.table('mag')
CGT.energy
plot(CGT,'range',[2 2 1])
CGT.table('matrix')


sel = 'Sperp'
figure;

%CGT.temperature(5)
fmkSpec = CGT.spinwave({[0 0 0] [.5 0 0] [1/3 1/3 0] [0 0 0] [0 0 1.5] 1000},'hermit',false,'formfact',true);
%fmkSpec = sw_neutron(fmkSpec,'pol',true,'uv',{u0 v0});
fmkSpec = sw_neutron(fmkSpec);
figure;
fmkSpec = sw_egrid(fmkSpec, 'Evect',linspace(0,35,100),'component',sel);
sw_plotspec(fmkSpec,'mode','color','axLim',[0 10],'dE',1)
sw_plotspec(fmkSpec,'mode','disp','axLim',[0 35],'colormap',[0 0 0],'colorbar',false,'lineStyle','-')
res = @(e) 6*10^(-6)*e.^3+0.0005*e.^2-0.0816*e+2.612;

%CGT.temperature(5)
fmkSpec = CGT.spinwave({[1 0 0] [1 0 3/2] 1000},'hermit',false,'formfact',true);
%fmkSpec = sw_neutron(fmkSpec,'pol',true,'uv',{u0 v0});
fmkSpec = sw_neutron(fmkSpec);
figure;
fmkSpec = sw_egrid(fmkSpec, 'Evect',linspace(0,35,100),'component',sel);
sw_plotspec(fmkSpec,'mode','color','axLim',[0 10],'dE',1)
sw_plotspec(fmkSpec,'mode','disp','axLim',[0 35],'colormap',[0 0 0],'colorbar',false,'lineStyle','-')
res = @(e) 6*10^(-6)*e.^3+0.0005*e.^2-0.0816*e+2.612;
res50 = @(e)2.6733*10^(-6)*e.^3+0.00061903*e.^2-0.10894*e+4.7861;
%% data
%
H0data = [      10.2500  4.41330e-005   9.54528e-006;
      10.7500  4.62080e-005   9.65140e-006;
      11.2500  4.55680e-005   9.66564e-006;
      11.7500  4.08920e-005   9.31796e-006;
      12.2500  3.80340e-005   9.45111e-006;
      12.7500  3.90490e-005   9.93817e-006;
      13.2500  4.08630e-005   9.83290e-006;
      13.7500  4.06170e-005   9.29901e-006;
      14.2500  3.79150e-005   8.59846e-006;
      14.7500  3.42390e-005   7.58238e-006;
      15.2500  3.22560e-005   6.74369e-006;
      15.7500  3.20150e-005   6.31267e-006;
      16.2500  3.31680e-005   6.29980e-006;
      16.7500  3.68450e-005   6.96091e-006;
      17.2500  4.16980e-005   7.74124e-006;
      17.7500  4.36750e-005   7.96404e-006;
      18.2500  4.34070e-005   8.15194e-006;
      18.7500  4.55390e-005   8.54895e-006;
      19.2500  4.92450e-005   8.40313e-006;
      19.7500  5.17770e-005   7.81625e-006;
      20.2500  5.25030e-005   7.45964e-006;
      20.7500  5.04450e-005   7.17203e-006;
      21.2500  5.07490e-005   7.36152e-006;
      21.7500  5.71940e-005   8.27484e-006;
      22.2500  6.29200e-005   8.88018e-006;
      22.7500  6.39230e-005   8.99361e-006;
      23.2500  6.48240e-005   9.34746e-006;
      23.7500  6.57530e-005   9.57346e-006;
      24.2500  6.78810e-005   9.35189e-006;
      24.7500  7.22280e-005   9.35178e-006;
      25.2500  7.49880e-005   9.67396e-006;
      25.7500  7.78000e-005   1.02305e-005;
      26.2500  8.14730e-005   1.05885e-005;
      26.7500  8.50960e-005   1.05195e-005;
      27.2500  8.97920e-005   1.06712e-005;
      27.7500  9.48080e-005   1.10962e-005;
      28.2500   0.000100044   1.16528e-005;
      28.7500   0.000105609   1.24987e-005;
      29.2500   0.000106948   1.33008e-005;
      29.7500   0.000101610   1.37330e-005;
      30.2500  9.04450e-005   1.41072e-005;
      30.7500  7.77940e-005   1.66057e-005;
      31.2500  7.18140e-005   2.30060e-005;
      31.7500  7.26720e-005   2.85548e-005];
HHdata = [      5.17999  6.17628e-005   1.09978e-005;
      5.64247  6.05511e-005   1.06044e-005;
      6.10499  6.06717e-005   1.08828e-005;
      6.47499  5.86809e-005   1.10718e-005;
      6.84499  5.57419e-005   1.08740e-005;
      7.21498  5.34439e-005   1.04733e-005;
      7.58498  4.96384e-005   9.69098e-006;
      8.04744  4.57094e-005   8.95854e-006;
      8.50997  4.38721e-005   8.95921e-006;
      8.87997  4.57709e-005   9.43501e-006;
      9.24997  4.92102e-005   9.76078e-006;
      9.61997  5.13548e-005   9.75947e-006;
      9.98996  5.24799e-005   9.41923e-006;
      10.4524  5.31896e-005   9.07363e-006;
      10.9150  5.32975e-005   9.21937e-006;
      11.2850  5.70202e-005   9.83696e-006;
      11.6549  5.87807e-005   1.00019e-005;
      12.0249  5.52457e-005   9.48682e-006;
      12.3949  5.18325e-005   8.72478e-006;
      12.8573  4.97212e-005   8.05895e-006;
      13.3199  4.72545e-005   7.87418e-006;
      13.6899  4.42603e-005   7.90575e-006;
      14.0599  4.15508e-005   7.78957e-006;
      14.4299  3.93714e-005   7.63783e-006;
      14.7999  3.93921e-005   7.61334e-006;
      15.1699  4.03846e-005   7.55761e-006;
      15.6322  4.34525e-005   7.95684e-006;
      16.0949  4.86186e-005   8.91965e-006;
      16.4649  5.50476e-005   9.92127e-006;
      16.8348  6.20125e-005   1.07909e-005;
      17.2048  6.89496e-005   1.15633e-005;
      17.5748  8.12487e-005   1.24567e-005;
      18.0369   0.000102121   1.42583e-005;
      18.4998   0.000122341   1.66777e-005;
      18.8697   0.000136909   1.86125e-005;
      19.2397   0.000144319   1.96701e-005;
      19.6097   0.000155590   2.06778e-005;
      19.9796   0.000159954   2.06882e-005;
      20.4412   0.000149112   1.98871e-005;
      20.9044   0.000133543   1.99534e-005;
      21.2743   0.000123512   2.06705e-005;
      21.6443   0.000116817   2.10830e-005;
      22.0141   0.000107334   2.08467e-005;
      22.3843  9.64233e-005   1.99742e-005;
      22.8459  9.07895e-005   2.01970e-005;
      23.3094  8.99852e-005   2.28710e-005;
      23.6795  8.89085e-005   2.64277e-005;
      24.0495  8.60022e-005   2.88065e-005];

coeff = max(H0data(:,2))-min(H0data(:,2));
H0data(:,3) = H0data(:,3)/coeff;
H0data(:,2) = (H0data(:,2)-min(H0data(:,2)))/coeff;
coeff = max(HHdata(:,2))-min(HHdata(:,2));
HHdata(:,3) = HHdata(:,3)/coeff;
HHdata(:,2) = (HHdata(:,2)-min(HHdata(:,2)))/coeff;
figure(22); hold on
errorbar(HHdata(:,1),HHdata(:,2),HHdata(:,3),'o')
figure(23); hold on
errorbar(H0data(:,1),H0data(:,2),H0data(:,3),'o')
%}
%% HH
h = [3^0.5/2 1/2 0];
k = [0 1 0];
l = [0 0 0.30136];%compression of L to z axis due to a and c being different
hk2xy = [h;k;l]';%transfer matrix from hkl to xyz
invhk2xy = inv([h;k;l]');
N = 20000;
nQ = 100;
nE = 350;
conv = zeros(nE,nQ);
%sigmax = 0.001/180*pi;
%sigmay = 0.001/180*pi;
%sigmaz = 0.001/180*pi;
sigmax = 2.766/180*pi;
sigmay = 2.766/180*pi;
sigmaz = 3.787/180*pi;
Jsigma = 0.41;
HKmosaic = @(x,y,z)exp(-x^2/(2*sigmax^2)-y^2/(2*sigmay^2)-z^2/(2*sigmaz^2));
Jcoefffun = @(e)exp(-e^2/(2*Jsigma^2));
%figure
hold on

CGT.temperature(55);

for i = 1:N
    i
    thetax = (rand()-0.5)*6*sigmax;
    thetay = (rand()-0.5)*6*sigmay;
    thetaz = (rand()-0.5)*6*sigmaz;%generate random mosaic
    dJ = (rand()-0.5)*6*Jsigma;
    NewJ1 = Js(1)+dJ;
    CGT.addmatrix('label','J1','value',NewJ1,'color','orange');
    rotmat = [[cos(thetaz), -sin(thetaz),0];[sin(thetaz),cos(thetaz),0];[0 0 1]]*...
        [[cos(thetay), 0, sin(thetay)];[0,1,0];[-sin(thetay) 0 cos(thetay)]]*...
        [[1,0,0];[0,cos(thetax),-sin(thetax)];[0 sin(thetax) cos(thetax)]];%generate random rotation matrix
    %x = cos(theta+pi/2);
    %y = sin(theta+pi/2);%magnetic field perpendicular
    Lrand = rand()*-5;
    Hrand = (rand()-0.5)*0.1;
    hhrange1 = invhk2xy*rotmat*hk2xy*[0 0+Hrand Lrand]';
    hhrange2 = invhk2xy*rotmat*hk2xy*[2 -1+Hrand Lrand]';
    %hhrange1 = invhk2xy*rotmat*hk2xy*[0+Hrand 0 Lrand]';
    %hhrange2 = invhk2xy*rotmat*hk2xy*[0+Hrand 2  Lrand]';%translation and rotation of the [h k l]
    %newhh = rlx*hk2xy*rotmat*invhk2xy;%rotation of the [h k l]

    Jcoeff = Jcoefffun(dJ);
    HKcoeff = HKmosaic(thetax,thetay,thetaz);
    %fdir = rotmat*[x,y,0]';
    %newhh(3) = Lrand/3;
    CGT.field([0 0 0]);
    CGT.genmagstr('mode','helical','k',[0 0 0],'n',[0 0 1],'S',[0;0;1]);
    [r,fmkSpec] = evalc("CGT.spinwave({hhrange1 hhrange2 nQ},'hermit',false,'formfact',true)");
    %fmkSpec = sw_neutron(fmkSpec,'pol',true,'uv',{u0 v0});
    fmkSpec = sw_neutron(fmkSpec);
    fmkSpec = sw_egrid(fmkSpec, 'Evect',linspace(0,35,nE+1),'component',sel);
    [r,fmkSpec] = evalc("sw_instrument(fmkSpec,'dE',res,'norm',false)");
    conv = conv+fmkSpec.swConv.*HKcoeff.*Jcoeff;

end 

fmkSpec.swConv = conv/max(max(conv));
figure
sw_plotspec(fmkSpec,'mode','color','axLim',[0 1])
colormap jet

figure(20); hold on

plot(0.1:0.1:35, sum(fmkSpec.swConv(:,45:55),2)/max(sum(fmkSpec.swConv(:,45:55),2)))

%% H0

h = [3^0.5/2 1/2 0];
k = [0 1 0];
l = [0 0 0.30136];%compression of L to z axis due to a and c being different
hk2xy = [h;k;l]';%transfer matrix from hkl to xyz
invhk2xy = inv([h;k;l]');
N = 10000;
nQ = 100;
nE = 350;
conv = zeros(nE,nQ);
%sigmax = 0.001/180*pi;
%sigmay = 0.001/180*pi;
%sigmaz = 0.001/180*pi;
sigmax = 2.766/180*pi;
sigmay = 2.766/180*pi;
sigmaz = 3.787/180*pi;

Jsigma = 0.3;
Jcoefffun = @(e)exp(-e^2/(2*Jsigma^2));

HKmosaic = @(x,y,z)exp(-x^2/(2*sigmax^2)-y^2/(2*sigmay^2)-z^2/(2*sigmaz^2));
%figure
hold on

for i = 1:N
    i
    dJ = (rand()-0.5)*6*Jsigma;
    NewJ1 = Js(1)+dJ;
    CGT.addmatrix('label','J1','value',NewJ1,'color','orange');
    thetax = (rand()-0.5)*6*sigmax;
    thetay = (rand()-0.5)*6*sigmay;
    thetaz = (rand()-0.5)*6*sigmaz;%generate random mosaic
    rotmat = [[cos(thetaz), -sin(thetaz),0];[sin(thetaz),cos(thetaz),0];[0 0 1]]*...
        [[cos(thetay), 0, sin(thetay)];[0,1,0];[-sin(thetay) 0 cos(thetay)]]*...
        [[1,0,0];[0,cos(thetax),-sin(thetax)];[0 sin(thetax) cos(thetax)]];%generate random rotation matrix
    %x = cos(theta+pi/2);
    %y = sin(theta+pi/2);%magnetic field perpendicular
    Lrand = rand()*-6;
    Hrand = (rand()-0.5)*0.1;
    %hhrange1 = invhk2xy*rotmat*hk2xy*[0 0+Hrand Lrand]';
    %hhrange2 = invhk2xy*rotmat*hk2xy*[2 -1+Hrand Lrand]';
    hhrange1 = invhk2xy*rotmat*hk2xy*[0+Hrand 0 Lrand]';
    hhrange2 = invhk2xy*rotmat*hk2xy*[0+Hrand 2  Lrand]';%translation and rotation of the [h k l]
    %newhh = rlx*hk2xy*rotmat*invhk2xy;%rotation of the [h k l]

    Jcoeff = Jcoefffun(dJ);
    HKcoeff = HKmosaic(thetax,thetay,thetaz);
    %fdir = rotmat*[x,y,0]';
    %newhh(3) = Lrand/3;
    CGT.field([0 0 0]);
    CGT.genmagstr('mode','helical','k',[0 0 0],'n',[0 0 1],'S',[0;0;1]);
    [r,fmkSpec] = evalc("CGT.spinwave({hhrange1 hhrange2 nQ},'hermit',false,'formfact',true)");
    %fmkSpec = sw_neutron(fmkSpec,'pol',true,'uv',{u0 v0});
    fmkSpec = sw_neutron(fmkSpec);
    fmkSpec = sw_egrid(fmkSpec, 'Evect',linspace(0,35,nE+1),'component',sel);
    [r,fmkSpec] = evalc("sw_instrument(fmkSpec,'dE',res50,'norm',false)");
    conv = conv+fmkSpec.swConv.*HKcoeff.*Jcoeff;

end 

fmkSpec.swConv = conv/max(max(conv));
figure
sw_plotspec(fmkSpec,'mode','color','axLim',[0 1])
colormap jet

figure(21); hold on

plot(0.1:0.1:35, sum(fmkSpec.swConv(:,45:55),2)/max(sum(fmkSpec.swConv(:,45:55),2)))
