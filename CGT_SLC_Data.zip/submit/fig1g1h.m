clear
load('BoseFac_for_fig1g1h.mat')

bfac = @(e,t)1./(1-exp(-e./(0.086173*t)));

figure;
hold on; 

Bfac7 = 1./(1-exp(-HHfit7KConstE(:,1)./(0.086173*7)));
Bfac50 = 1./(1-exp(-HHfit7KConstE(:,1)./(0.086173*50)));

errorbar(HHfit7KConstE(:,1),HHfit7KConstE(:,2)./Bfac7,HHfit7KConstE(:,3)./Bfac7);
errorbar(HHfit50KConstE(:,1),HHfit50KConstE(:,2)./Bfac50,HHfit50KConstE(:,3)./Bfac50);
legend('7K','50K')


figure;
hold on; 
Bfac7 = 1./(1-exp(-2./(0.086173*7)));
Bfac50 = 1./(1-exp(-2./(0.086173*50)));

x1=T7K2meV(:,1);
y1=T7K2meV(:,2)./Bfac7;
x2=T50K2meV(:,1);
y2=T50K2meV(:,2)./Bfac50;

errorbar(T7K2meV(:,1),T7K2meV(:,2)./Bfac7,T7K2meV(:,3)./Bfac7,'o');
errorbar(T50K2meV(:,1),T50K2meV(:,2)./Bfac50,T50K2meV(:,3)./Bfac50,'o');

xx=-0.3:0.001:0.3
plot(xx,0.2988*exp(-((xx-0.1116)/0.03038).^2)+0.2988*exp(-((xx+.1116)/.03038).^2))
plot(xx,0.155*exp(-((xx-0.1154)/0.044).^2)+0.155*exp(-((xx+.1154)/.044).^2))
legend('7K','50K')
ratio1=.2988*.03038/.155/.044

figure;
hold on; 
Bfac7 = 1./(1-exp(-1.5/(0.086173*7)));
Bfac50 = 1./(1-exp(-1.5/(0.086173*50)));

x1=T7K1p5meVH(:,1);
y1=T7K1p5meVH(:,2)./Bfac7;
x2=T50K1p5meVH(:,1);
y2=T50K1p5meVH(:,2)./Bfac50;

errorbar(x1,y1,T7K1p5meVH(:,3)./Bfac7,'o');
errorbar(x2,y2,T50K1p5meVH(:,3)./Bfac50,'o');

xx=-0.3:0.001:0.3
plot(xx,0.257*exp(-((xx-0.09431)/0.02579).^2)+0.257*exp(-((xx+0.09431)/0.02579).^2))
plot(xx,0.1613*exp(-((xx-0.1039)/0.02992).^2)+0.1613*exp(-((xx+0.1039)/0.02992).^2))
legend('7K','50K')
title('Fig.1g')

figure;
hold on; 

Bfac7 = 1./(1-exp(-1.5./(0.086173*7)));
Bfac50 = 1./(1-exp(-1.5./(0.086173*50)));
x1=T7K1p5meVL(:,1);
y1=T7K1p5meVL(:,2)./Bfac7;
x2=T50K1p5meVL(:,1);
y2=T50K1p5meVL(:,2)./Bfac50;

errorbar(T7K1p5meVL(:,1),T7K1p5meVL(:,2)./Bfac7,T7K1p5meVL(:,3)./Bfac7,'o');
errorbar(T50K1p5meVL(:,1),T50K1p5meVL(:,2)./Bfac50,T50K1p5meVL(:,3)./Bfac50,'o');

xx=1.5:0.001:3
plot(xx,1.016*exp(-((xx-2.232)/0.06007).^2))
plot(xx,0.8764*exp(-((xx-2.131)/0.07697).^2))
legend('7K','50K')
ratio2=1.016*.06007/.8764/.07697
title('Fig.1h')

figure;hold on;
for e=3:8
    Bfac7 = bfac(e,7);
    Bfac50 = bfac(e,50);
    subplot(3,2,e-2)
    hold on;
    box on;
    errorbar(HH7KEcuts(:,1),HH7KEcuts(:,e*4+2)./Bfac7,HH7KEcuts(:,e*4+3)./Bfac7,'o-');
    errorbar(HH50KEcuts(:,1),HH50KEcuts(:,e*4+2)./Bfac50,HH50KEcuts(:,e*4+3)./Bfac50,'o-');
    sum(HH7KEcuts(:,e*4+2)./Bfac7)/sum(HH50KEcuts(:,e*4+2)./Bfac50)
    title(['E=',int2str(e),'meV'],'FontName', 'Arial')
    xlabel('[H H] (r. l. u.)','FontName', 'Arial')
    ylabel('I (Bose Factor corrected)','FontName', 'Arial')
    legend('7K',"50K")
end

figure;hold on;
es = [1.0 1.2 1.4 1.6 1.8 1.93]
for i=1:6
    e=es(i);
    Bfac7 = bfac(es(i),7);
    Bfac50 = bfac(es(i),50);
    subplot(3,2,i);hold on;box on;
    errorbar(L7KEcuts(:,1),L7KEcuts(:,i*4-2)./Bfac7,L7KEcuts(:,i*4-1)./Bfac7,'o-');
    errorbar(L50KEcuts(:,1),L50KEcuts(:,i*4-2)./Bfac50,L50KEcuts(:,i*4-1)./Bfac50,'o-');
    sum(L7KEcuts(:,i*4-2)./Bfac7)/sum(L50KEcuts(:,i*4-2)./Bfac50)
    title(['E=',num2str(e),'meV'],'FontName', 'Arial')
    xlabel('[0 0 L] (r. l. u.)','FontName', 'Arial')
    ylabel('I (Bose Factor corrected)','FontName', 'Arial')
    legend('7K',"50K")
end

x7 = HHE7K(:,1);
Bfac7 = bfac(x7,7);
y7 = HHE7K(:,2)./Bfac7;
y7err = HHE7K(:,3)./Bfac7;

x50 = HHE50K(:,1);
Bfac50 = bfac(x50,50);
y50 = HHE50K(:,2)./Bfac50;
y50err = HHE50K(:,3)./Bfac50;

figure; hold on 

errorbar(x7,y7,y7err,'o-')
errorbar(x50,y50,y50err,'o-')
xlabel('E (meV)','FontName', 'Arial')
ylabel('I (Bose Factor corrected)','FontName', 'Arial')
legend('7K',"50K")

x7 = LE7K(:,1);
Bfac7 = bfac(x7,7);
y7 = LE7K(:,2)./Bfac7;
y7err = LE7K(:,3)./Bfac7;

x50 = LE50K(:,1);
Bfac50 = bfac(x50,50);
y50 = LE50K(:,2)./Bfac50;
y50err = LE50K(:,3)./Bfac50;

figure; hold on 

errorbar(x7,y7,y7err,'o-')
errorbar(x50,y50,y50err,'o-')
xlabel('E (meV)','FontName', 'Arial')
ylabel('I (Bose Factor corrected)','FontName', 'Arial')
legend('7K',"50K")

figure;hold on;
es = [1.2 1.4 1.6 1.8]
T7Kdata = [E1p2 E1p4 E1p6 E1p8]
T50Kdata = [E1p250 E1p450 E1p650 E1p850]
for i=1:4
    e=es(i);
    Bfac7 = bfac(es(i),7);
    Bfac50 = bfac(es(i),50);
    subplot(3,2,i);hold on;box on;
    errorbar(T7Kdata(:,i*3-2),T7Kdata(:,i*3-1)./Bfac7,T7Kdata(:,i*3)./Bfac7,'o-');
    errorbar(T50Kdata(:,i*3-2),T50Kdata(:,i*3-1)./Bfac50,T50Kdata(:,i*3)./Bfac50,'o-');
    sum(L7KEcuts(:,i*4-2)./Bfac7)/sum(L50KEcuts(:,i*4-2)./Bfac50)
    title(['E=',num2str(e),'meV'],'FontName', 'Arial')
    xlabel('[0 0 L] (r. l. u.)','FontName', 'Arial')
    ylabel('I (Bose Factor corrected)','FontName', 'Arial')
    legend('7K',"50K")
end


x7 = LE7K4p5to6(:,1);
Bfac7 = bfac(x7,7);
y7 = LE7K4p5to6(:,2)./Bfac7;
y7err = LE7K4p5to6(:,3)./Bfac7;

x50 = LE50K4p5to6(:,1);
Bfac50 = bfac(x50,50);
y50 = LE50K4p5to6(:,2)./Bfac50;
y50err = LE50K4p5to6(:,3)./Bfac50;

x72 = []
y72=[]
y72err = []
for i = 1:37
    x72(i) = (x7(i*3)+x7(i*3-1)+x7(i*3-2))/3
    y72(i) = (y7(i*3)+y7(i*3-1)+y7(i*3-2))/3
    y72err(i) = ((y7err(i*3)^2+y7err(i*3-1)^2+y7err(i*3-2)^2))^.5/3
end

x502 = []
y502=[]
y502err = []
for i = 1:35
    x502(i) = (x50(i*3)+x50(i*3-1)+x50(i*3-2))/3
    y502(i) = (y50(i*3)+y50(i*3-1)+y50(i*3-2))/3
    y502err(i) = ((y50err(i*3)^2+y50err(i*3-1)^2+y50err(i*3-2)^2))^.5/3
end
figure; hold on 


errorbar(x72,y72,y72err,'o-')
errorbar(x502,y502,y502err,'o-')
xlabel('E (meV)','FontName', 'Arial')
ylabel('I (Bose Factor corrected)','FontName', 'Arial')
legend('7K',"50K")
xlim([0,3.5])
ylim([0,.5])